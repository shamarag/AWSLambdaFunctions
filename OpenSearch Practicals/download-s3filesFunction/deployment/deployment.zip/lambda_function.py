import boto3
import json
import requests
from requests_aws4auth import AWS4Auth


region = 'us-east-2' # e.g. us-west-1
service = 'es'
credentials = boto3.Session().get_credentials()
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

s3 = boto3.resource('s3')

# Lambda execution starts here
def lambda_handler(event, context):
        bucket = event['queryStringParameters']['bucket']
        key = event['queryStringParameters']['key']

        try:
            fileObj = s3.get_object(Bucket=bucket, Key=key)
            fileContent = fileObj["Body"].read()
            print(bucket, key)

            return{
                "statusCode": 200,
                "headers": {
                    "Content-Type": "application/pdf",
                    "Content-Disposition": "attachment; filename={}".format(key)
                },
                "body": base64.b64encode(fileContent),
                "isBase64Encoded": True
            }


        except Exception as e:
            print("Error")

